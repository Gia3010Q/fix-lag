# Bản nguồn tách riêng Mizuauto

Bản sửa WinForms hiện tại dùng hồ sơ riêng và có thể phối hợp Multi Roblox với RAM gốc. Xem hướng dẫn cài/build và giới hạn kiểm chứng tại [STANDALONE.vi.md](upstream-ram-372/STANDALONE.vi.md). Các hướng dẫn bên dưới về đặt EXE cạnh RAM và dùng dữ liệu chung thuộc bản cũ, không áp dụng cho bản tách riêng.

---

# Mizuauto

**Bản đầy đủ quản lý nhiều tài khoản:** source tại [`upstream-ram-372`](upstream-ram-372/MIZUAUTO.md), biên dịch từ Roblox Account Manager 3.7.2 và thêm cửa sổ tối ưu RAM/CPU. File `mizuauto.exe` mới được đặt cạnh bản RAM 3.7.2 đang có trong `Downloads/Roblox.Account.Manager.3.7.2`, để dùng cùng dữ liệu tài khoản hiện có. Đóng RAM và Mizuauto cũ trước khi mở bản này. Chi tiết bản quyền và cách build ở `upstream-ram-372/MIZUAUTO.md`.

Trong bản đầy đủ, chọn nhiều tài khoản, nhập Place ID rồi dùng nút Join Server của RAM. Cài đặt `EnableMultiRbx=true` trên máy này đang bật. Cửa sổ **Tối ưu RAM/CPU** mở cùng ứng dụng và có thể gọi lại từ nút trên cửa sổ chính. Chế độ Auto thu hồi RAM từ 384 MB; CPU chọn Tắt, 2 luồng hoặc 1 luồng. Chế độ 1 luồng có thể giảm FPS và gây giật.

Phần dưới mô tả bản Mizuauto Python trước đó, vẫn giữ lại trong workspace để tham khảo.

Mở `dist/manager/mizuauto.exe` và chấp nhận hộp thoại quyền quản trị của Windows. Ứng dụng dùng logo trong `assets/mizulogo.png` và tự nhận mọi cửa sổ Roblox hiện có hoặc mở sau.

Bấm **Tài khoản** để dùng cùng Roblox Account Manager (RAM) đã cài trên máy. Nhập mật khẩu API của RAM (nếu đã đặt), bấm **Kết nối**, chọn nhiều tài khoản, nhập **Place ID** rồi bấm **Mở đã chọn**. Mizuauto gửi lệnh mở lần lượt theo khoảng trễ đã đặt trong RAM. Nút **Mở RAM** đưa cửa sổ RAM lên để thêm hoặc chỉnh tài khoản. Cần bật **Enable Web Server**, **Allow Get Accounts**, **Allow Launch Account** và **Multi Roblox** trong RAM; các mục này đang bật ở bản RAM 3.7.2 trên máy này. Mizuauto chỉ nhận tên, bí danh và nhóm qua API nội bộ; không đọc cơ sở dữ liệu tài khoản, sao chép cookie hay lưu mật khẩu API. [Tài liệu API của RAM](https://ic3w0lf22.gitbook.io/roblox-account-manager).

Nhập chu kỳ từ **0,1 đến 3600 giây** (chấp nhận cả `0.1` và `0,1`), rồi bấm **Áp dụng**. Auto dùng chu kỳ đã lưu khi mở lại. Nếu bản Roblox Gọn Máy cũ còn chạy, Mizuauto chờ bản đó đóng để tránh hai ứng dụng cùng thu hồi RAM.

Để giảm thao tác lặp lại, Mizuauto chỉ gọi `EmptyWorkingSet` khi RAM đang dùng của một phiên đạt ít nhất **384 MB**. Mức này cho phép thu hồi lại khi phiên tăng lên 500–600 MB. Nếu một lượt xử lý lâu hơn chu kỳ đã đặt, lượt mới đợi lượt cũ xong. Giao diện vẫn phản hồi vì việc thu hồi chạy ở luồng nền. Ứng dụng không ghi log mỗi chu kỳ; file trạng thái chỉ cập nhật khi đổi chu kỳ hoặc bật/tắt Auto.

Mục **CPU** có ba lựa chọn: **Tắt** (mặc định), **2 luồng**, **1 luồng**. Giới hạn được áp dụng riêng cho mọi phiên Roblox có cửa sổ, kể cả phiên mở sau, ngay khi chọn chế độ. Mizuauto giảm ưu tiên tiến trình xuống mức *Below normal* và giới hạn số luồng CPU được phép chạy. Khi chọn **Tắt** hoặc đóng Mizuauto, công cụ khôi phục số luồng và mức ưu tiên ban đầu. Chế độ này có thể giảm mức sử dụng CPU tối đa nhưng cũng có thể làm game giảm FPS hoặc giật, nhất là **1 luồng**. Bật **2 luồng** trước nếu cần giữ độ mượt. [Tài liệu Microsoft về CPU affinity](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-setprocessaffinitymask).

Nhấp chuột phải vào một phiên trong bảng để thu hồi một lần hoặc đóng riêng phiên đó. Chỉ số RAM có thể giảm tạm thời rồi tăng lại khi Roblox dùng bộ nhớ; cột **Đã cấp phát** không giảm vì thao tác này. Chu kỳ quá ngắn vẫn có thể gây giật hoặc tăng hoạt động ổ đĩa. [Tài liệu Microsoft về working set](https://learn.microsoft.com/en-us/windows/win32/psapi/working-set-information).

Đóng gói lại trên Windows:

```powershell
python -m PyInstaller --onefile --windowed --uac-admin --clean --name mizuauto --distpath dist/manager --icon assets/mizuauto.ico --add-data "assets/mizulogo.png;assets" roblox_optimizer.py
```
